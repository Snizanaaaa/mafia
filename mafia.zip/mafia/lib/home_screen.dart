import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(body: SafeArea(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            ElevatedButton(onPressed: () {
              GoRouter.of(context).push("/offline");
            }, child: Text("Офлайн")),
            const SizedBox(height: 32),
            ElevatedButton(onPressed: () {
              // TODO: Add online
            }, child: Text("Онлайн")),
          ],
        ),
      ),
    ));
  }
}
