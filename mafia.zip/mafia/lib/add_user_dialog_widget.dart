import 'package:flutter/material.dart';

class AddUserDialogWidget extends StatefulWidget {
  const AddUserDialogWidget({super.key});

  @override
  State<AddUserDialogWidget> createState() => _AddUserDialogWidgetState();
}

class _AddUserDialogWidgetState extends State<AddUserDialogWidget> {
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
        content: IntrinsicHeight(
            child: Column(
              children: [
                TextField(),
                ElevatedButton(onPressed: () {}, child: Text("Добавити"))
              ],
            )
        )
    );
  }
}
