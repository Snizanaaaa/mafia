import 'package:go_router/go_router.dart';
import 'package:mafia/home_screen.dart';
import 'package:mafia/offline_mode_screen.dart';

final router = GoRouter(
    initialLocation: '/',
    routes: [
      GoRoute(path: '/', builder: (context, state) {
        return const HomeScreen();
      }),
      GoRoute(path: '/offline', builder: (context, state) {
        return const OfflineModeScreen();
      })
    ]
);