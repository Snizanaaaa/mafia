import 'package:flutter/material.dart';
import 'package:mafia/user.dart';

class PlayerListItemWidget extends StatelessWidget {
  final User player;
  const PlayerListItemWidget({super.key, required this.player});

  @override
  Widget build(BuildContext context) {
    return Text(player.name);
  }
}
