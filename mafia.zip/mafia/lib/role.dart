enum Role {
  none,
  mafia,
  citizen,
  doctor,
  sheriff,
  lady,
  killer,
  boss
}