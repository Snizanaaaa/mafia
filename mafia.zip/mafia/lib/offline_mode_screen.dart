import 'package:flutter/material.dart';
import 'package:mafia/add_user_dialog_widget.dart';
import 'package:mafia/players_list_widget.dart';
import 'package:mafia/role.dart';
import 'package:mafia/user.dart';

class OfflineModeScreen extends StatefulWidget {
  const OfflineModeScreen({super.key});

  @override
  State<OfflineModeScreen> createState() => _OfflineModeScreenState();
}

class _OfflineModeScreenState extends State<OfflineModeScreen> {
  final players = <User>[User(Role.none, "John Wick")];


  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar:AppBar(
          title: Text('Нова гра'),
        ),
        body: Column(
          children: [
            PlayersListWidget(players: players),
            ElevatedButton(onPressed: () async {
              final name = await showDialog <String?> (context: context, builder: (context) {
                return AddUserDialogWidget();
              });

              if  (name == null) {
                return;
              }

              players.add(User(Role.none, name));
              setState(() {});
            }, child: Column(
              children: [
                Text("Добавити"),
              ],
            )),
          ],
        ));
  }
}