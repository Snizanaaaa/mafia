import 'package:mafia/role.dart';

class User {
  final Role role;
  final String name;

  User(this.role, this.name);
}